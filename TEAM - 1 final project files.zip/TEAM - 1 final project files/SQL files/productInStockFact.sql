--productInStock fact


--drop table [north_factsdim].[ProductInStock_Fact]
create table [north_factsdim].[ProductInStock_Fact](
[CalendarKey][integer]FOREIGN KEY REFERENCES north_factsdim.Calendar_Dim(CalendarKey),
[productKey][integer]FOREIGN KEY REFERENCES north_factsdim.Products_Dim(ProductKey),
[CategoriesKey][integer]FOREIGN KEY REFERENCES north_factsdim.Categories_Dim(CategoriesKey),
[SupplierKey][integer]FOREIGN KEY REFERENCES north_factsdim.Suppliers_Dim(SupplierKey),
[UnitsInStock][integer]not null,
[UnitsOnOrder][integer]not null,
[ReorderLevel][integer]not null,
[TotalQuantity][integer]not null,
[OrderId] varchar(max) not null
);

--data loading into the productinstock fact
/*
INSERT INTO [north_factsdim].[ProductInStock_Fact] (
    [CalendarKey],
    [productKey],
    [CategoriesKey],
    [SupplierKey],
    [UnitsInStock],
    [UnitsOnOrder],
    [ReorderLevel],
    [TotalQuantity],
    [OrderId]
)
SELECT
    cd.CalendarKey,
    pd.ProductKey,
    cat.CategoriesKey,
    sd.SupplierKey,
    pd.UnitsInStock,
    pd.UnitsOnOrder,
    pd.ReorderLevel,
    (pd.UnitsInStock + pd.UnitsOnOrder) AS TotalQuantity, 
    o.OrderId
FROM
	north.Orders o
	join
	north.OrderDetails od
	on o.OrderID = od.OrderID
	join north_factsdim.Products_Dim pd
	on od.ProductID = pd.ProductID
	join north_factsdim.Calendar_Dim cd
	on o.OrderDate = cd.FullDate
	join north_factsdim.Categories_Dim cat 
	on cat.CategoryID = pd.CategoryID
    join north_factsdim.Suppliers_Dim sd
	on sd.SupplierID = pd.SupplierID
*/
select * from north_factsdim.[ProductInStock_Fact];


with LatestProducts as (
select * from north_factsdim.Products_Dim where VersionNumber = 0
)
INSERT INTO [north_factsdim].[ProductInStock_Fact] (
    [CalendarKey],
    [ProductKey],
    [CategoriesKey],
    [SupplierKey],
    [UnitsInStock],
    [UnitsOnOrder],
    [ReorderLevel],
    [TotalQuantity],
    [OrderId]
)
SELECT
    cd.CalendarKey,
    lp.ProductKey,
    cat.CategoriesKey,
    sd.SupplierKey,
    lp.UnitsInStock,
    lp.UnitsOnOrder,
    lp.ReorderLevel,
    (lp.UnitsInStock + lp.UnitsOnOrder) AS TotalQuantity,
    o.OrderId
FROM
    north.Orders o
    JOIN north.OrderDetails od ON o.OrderID = od.OrderID
    JOIN LatestProducts lp ON od.ProductID = lp.ProductID
    JOIN north_factsdim.Calendar_Dim cd ON o.OrderDate = cd.FullDate
    JOIN north_factsdim.Categories_Dim cat ON cat.CategoryID = lp.CategoryID
    JOIN north_factsdim.Suppliers_Dim sd ON sd.SupplierID = lp.SupplierID;





--testing
--756515816
--2061615059
select * from north_factsdim.ProductInStock_Fact where productKey = 2061615059;
select * from north_factsdim.Products_Dim;
select productKey from north_factsdim.Products_Dim where ProductID = 2;
update north_factsdim.Products_Dim
set 
ProductName = 'parantha' where productID = 2;




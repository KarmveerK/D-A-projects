-- Analysis on discontinued products using the fact table

--listing all the products discontinued
SELECT
    f.productKey AS ProductKey,
    p.ProductName,
    p.CategoryID,
    p.SupplierID,
    p.UnitPrice
FROM
    [north_factsdim].[ProductInStock_Fact] f
JOIN
    [north_factsdim].[Products_Dim] p 
ON f.productKey = p.Productkey
WHERE
    p.Discontinued = 1;

-- Count of discontinued products in the fact table
SELECT
    COUNT(*) AS DiscontinuedProductCount
FROM
    [north_factsdim].[ProductInStock_Fact] f
JOIN
    [north_factsdim].[Products_Dim] p ON f.productKey = p.Productkey
WHERE
    p.Discontinued = 1;


-- Best selling product in each category
WITH RankedProducts AS (
    SELECT
        pd.ProductID,
        pd.ProductName,
        c.CategoryName,
        SUM(fact.TotalQuantity) AS TotalQuantitySold,
        ROW_NUMBER() OVER (PARTITION BY c.CategoryName ORDER BY SUM(fact.TotalQuantity) DESC) AS RankWithinCategory
    FROM
        north_factsdim.ProductInStock_Fact fact
    JOIN
        north_factsdim.Products_Dim pd ON fact.productKey = pd.ProductKey
    JOIN
        north_factsdim.Categories_Dim c ON fact.CategoriesKey = c.CategoriesKey
    GROUP BY
        pd.ProductID, pd.ProductName, c.CategoryName
)
SELECT
	CategoryName,
    ProductID,
    ProductName,
    TotalQuantitySold
FROM
    RankedProducts
WHERE
    RankWithinCategory = 1;


-- min max avg customer billing
SELECT
    c.CustomerID,
    c.phone,
    MIN(ce.Sales) AS MinBilling,
    MAX(ce.Sales) AS MaxBilling,
    AVG(ce.Sales) AS AvgBilling
FROM
    north_factsdim.CustomerEmployee_Fact ce
left join
    north_factsdim.Customers_Dim c ON ce.CustomerKey = c.CustomerKey
GROUP BY
    c.CustomerID, c.phone;

--best salesperson

SELECT top 1
    e.EmployeeID, 
	e.firstName,
	e.lastName,
    SUM(ce.Sales) AS TotalSales
FROM
    north_factsdim.CustomerEmployee_Fact ce
JOIN
    north_factsdim.Employees_Dim e ON ce.EmployeeKey = e.EmployeeKey
GROUP BY
    e.EmployeeID,e.firstName,e.lastName
ORDER BY
    TotalSales DESC


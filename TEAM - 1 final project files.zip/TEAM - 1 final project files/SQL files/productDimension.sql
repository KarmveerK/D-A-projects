
--data landing table of products
CREATE TABLE [north].[Products](
	[ProductID] [int] NOT NULL,
	[ProductName] [nvarchar](40) NOT NULL,
	[SupplierID] [int] NULL,
	[CategoryID] [int] NULL,
	[QuantityPerUnit] [nvarchar](20) NULL,
	[UnitPrice] [money] NULL,
	[UnitsInStock] [smallint] NULL,
	[UnitsOnOrder] [smallint] NULL,
	[ReorderLevel] [smallint] NULL,
	[Discontinued] [bit] NOT NULL)
--populating data in products landing table has been done using python

--creating the staging table for products
CREATE TABLE [north].[STG_Products](
	[ProductID] [int] NOT NULL,
	[ProductName] [nvarchar](40) NOT NULL,
	[SupplierID] [int] NULL,
	[CategoryID] [int] NULL,
	[QuantityPerUnit] [nvarchar](20) NULL,
	[UnitPrice] [money] NULL,
	[UnitsInStock] [smallint] NULL,
	[UnitsOnOrder] [smallint] NULL,
	[ReorderLevel] [smallint] NULL,
	[Discontinued] [bit] NOT NULL
)


--demo table <- [north].[Products]
--duplicate inserts should not be there
--version number should work correctly

--populating the data into products staging table using SCD -1
merge into north.STG_Products sp
using north.Products lp
on sp.ProductID = lp.ProductID
when matched and (sp.ProductName <> lp.ProductName 
or sp.SupplierID <> lp.SupplierID or sp.CategoryID <> lp.CategoryID 
or sp.QuantityPerUnit <> lp.QuantityPerUnit or sp.UnitPrice <> lp.UnitPrice 
or sp.UnitsInStock <> lp.UnitsInStock or sp.UnitsOnOrder <> lp.UnitsOnOrder
or sp.ReorderLevel <> lp.ReorderLevel or sp.Discontinued <> lp.Discontinued)
then update
set
sp.ProductID = lp.ProductID,
sp.ProductName = lp.ProductName,
sp.SupplierID = lp.SupplierID,
sp.CategoryID = lp.CategoryID,
sp.QuantityPerUnit = lp.QuantityPerUnit,
sp.UnitPrice = lp.UnitPrice,
sp.UnitsInStock = lp.UnitsInStock,
sp.UnitsOnOrder = lp.UnitsOnOrder,
sp.ReorderLevel = lp.ReorderLevel,
sp.Discontinued = lp.Discontinued
when not matched
then insert values
(lp.ProductID, lp.ProductName, lp.SupplierID,lp.CategoryID,lp.QuantityPerUnit,lp.UnitPrice,lp.
UnitsInStock,lp.UnitsOnOrder,lp.ReorderLevel,lp.Discontinued)
when not matched by source
then delete;

--creating the products dimension table.
CREATE TABLE [north_factsdim].[Products_Dim](
    [productKey][integer]primary key,
	[ProductID] [int] not null,
	[ProductName] [nvarchar](40) NOT NULL,
	[SupplierID] [int] NULL,
	[CategoryID] [int] NULL,
	[QuantityPerUnit] [nvarchar](20) NULL,
	[UnitPrice] [money] NULL,
	[UnitsInStock] [smallint] NULL,
	[UnitsOnOrder] [smallint] NULL,
	[ReorderLevel] [smallint] NULL,
	[Discontinued] [bit] NOT NULL,
	VersionNumber integer NOT NULL DEFAULT 0
)
update north.STG_Products 
set ProductName = 'golgappa' where ProductID = 2;
-- populating data into product dimensions using SCD - 2

select * from [north_factsdim].[Products_Dim]
 
MERGE INTO  [north_factsdim].[Products_Dim] sp
USING north.STG_Products lp
ON sp.productID = lp.productID
WHEN MATCHED AND 
(sp.productKey <>  Hashbytes ('MD5', concat(lp.ProductID, lp.ProductName, lp.SupplierID,lp.CategoryID,
lp.QuantityPerUnit,lp.UnitPrice,lp.UnitsInStock,lp.UnitsOnOrder,lp.ReorderLevel,lp.Discontinued, 0)) )
THEN UPDATE 
SET
sp.VersionNumber = sp.VersionNumber-1 
when not matched
THEN INSERT
VALUES(Hashbytes ('MD5', concat( lp.ProductID, lp.ProductName, lp.SupplierID,lp.CategoryID,
lp.QuantityPerUnit,lp.UnitPrice,lp.UnitsInStock,lp.UnitsOnOrder,lp.ReorderLevel,lp.Discontinued, 0)),
lp.ProductID, lp.ProductName, lp.SupplierID,lp.CategoryID,lp.QuantityPerUnit,lp.UnitPrice,lp.UnitsInStock,
lp.UnitsOnOrder,lp.ReorderLevel,lp.Discontinued, 0)
WHEN NOT MATCHED BY SOURCE
THEN DELETE;
 
insert into  [north_factsdim].[Products_Dim](productKey,ProductID,ProductName,SupplierID,CategoryID,
QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued,VersionNumber)
select Hashbytes('MD5',concat(ProductID,ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,
UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued,0)) as skey,*,0 from  north.STG_Products
where Hashbytes('MD5',concat(ProductID,ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,
UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued,0)) not in (Select productKey from  [north_factsdim].[Products_Dim]);
 
 
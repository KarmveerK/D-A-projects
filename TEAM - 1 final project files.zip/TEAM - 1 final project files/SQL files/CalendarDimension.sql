--calander dimension
--creating table for calendar dimension
create table [north_factsdim].[Calendar_Dim](
[CalendarKey][integer]primary key,
[FullDate][datetime] not null,
[Dayoftheweek]varchar(max) not null,
[DayType]varchar(max)not null,
[Dayofthemonth][integer]not null,
[month]varchar(max)not null,
[Quarter]varchar(max)not null,
[Year][integer]not null
)
--changing the data type of dayoftheweek,daytypemmonth and quarter into varchar(max)


--populating the caledar dimension
--case1: initially the calendar dimension would be empty so we will include all the order dates in the dimension
--case2: when new orders are added to the orders, we only want to insert those ordedates which are not in the calendar dimension.


-- Create a temporary table to store new orders data
CREATE TABLE #NewOrders (
    orderdate DATETIME
);

-- Check if Calendar_Dim is empty
IF NOT EXISTS (SELECT 1 FROM north_factsdim.Calendar_Dim)
BEGIN
    -- Perform a full load for the first time
    INSERT INTO north_factsdim.Calendar_Dim (CalendarKey, FullDate, Dayoftheweek, DayType, Dayofthemonth, [Month], Quarter, [Year])
    SELECT distinct
        CONVERT(INT, FORMAT(orderdate, 'yyyyMMdd')) AS CalendarKey,
        orderdate AS FullDate,
        FORMAT(orderdate, 'dddd') AS Dayoftheweek,
        CASE WHEN DATEPART(dw, orderdate) IN (1, 7) THEN 'Weekend' ELSE 'Weekday' END AS DayType,
        DAY(orderdate) AS Dayofthemonth,
        FORMAT(orderdate, 'MMMM') AS [Month],
        'Q' + CAST(DATEPART(QUARTER, orderdate) AS CHAR) AS Quarter,
        YEAR(orderdate) AS [Year]
    FROM
        north.STG_Orders;
END
ELSE
BEGIN
    -- Populate the temporary table with new orders data
	--we are using distinct here because we only want unique values of the orderdates otherwise the calendarkey will contradict.
    INSERT INTO #NewOrders (orderdate)
    SELECT distinct orderdate
    FROM north.STG_Orders
    WHERE orderdate > (SELECT MAX(FullDate) FROM north_factsdim.Calendar_Dim);

    -- Insert only new values into Calendar_Dim
    INSERT INTO north_factsdim.Calendar_Dim (CalendarKey, FullDate, Dayoftheweek, DayType, Dayofthemonth, [Month], Quarter, [Year])
    SELECT
        CONVERT(INT, FORMAT(orderdate, 'yyyyMMdd')) AS CalendarKey,
        orderdate AS FullDate,
        FORMAT(orderdate, 'dddd') AS Dayoftheweek,
        CASE WHEN DATEPART(dw, orderdate) IN (1, 7) THEN 'Weekend' ELSE 'Weekday' END AS DayType,
        DAY(orderdate) AS Dayofthemonth,
        FORMAT(orderdate, 'MMMM') AS [Month],
        'Q' + CAST(DATEPART(QUARTER, orderdate) AS CHAR) AS Quarter,
        YEAR(orderdate) AS [Year]
    FROM
        #NewOrders;
END

-- Drop the temporary table
DROP TABLE #NewOrders;



select * from north_factsdim.Calendar_Dim





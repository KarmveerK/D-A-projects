--creating the landing table for employees
CREATE TABLE [north].[Employees](
	[EmployeeID] [int] NOT NULL,
	[LastName] [nvarchar](20) NOT NULL,
	[FirstName] [nvarchar](10) NOT NULL,
	[BirthDate] [datetime] NULL,
	[HireDate] [datetime] NULL,
	[Region] [nvarchar](15) NULL,
	[Country] [nvarchar](15) NULL)
--populating the data in employees landing table is done using python

--employees staging table
CREATE TABLE [north].[STG_Employees](
	[EmployeeID] [int] NOT NULL,
	[LastName] [nvarchar](20) NOT NULL,
	[FirstName] [nvarchar](10) NOT NULL,
	[BirthDate] [datetime] NULL,
	[HireDate] [datetime] NULL,
	[Region] [nvarchar](15) NULL,
	[Country] [nvarchar](15) NULL
)
--populating the staging table of employees using SCD - 1
merge into north.STG_Employees sc
using north.Employees lc
on sc.EmployeeID = lc.EmployeeID
when matched and (sc.LastName <> lc.LastName or sc.FirstName <> lc.FirstName or sc.BirthDate<>lc.BirthDate or sc.HireDate<>lc.HireDate or sc.Region<>lc.Region or sc.Country<>lc.Country)
then update
set
sc.LastName = lc.LastName,
sc.FirstName = lc.FirstName,
sc.BirthDate = lc.BirthDate,
sc.HireDate = lc.HireDate,
sc.Region = lc.Region,
sc.Country = lc.Country
when not matched
then insert values(lc.EmployeeID, lc.LastName, lc.FirstName, lc.BirthDate, lc.HireDate, lc.Region, lc.Country)
when not matched by source
then delete;

--employees dimension creation
CREATE TABLE [north_factsdim].[Employees_Dim](
    [EmployeeKey][integer] primary key,
	[EmployeeID] [int] NOT NULL,
	[LastName] [nvarchar](20) NOT NULL,
	[FirstName] [nvarchar](10) NOT NULL,
	[BirthDate] [datetime] NULL,
	[HireDate] [datetime] NULL,
	[Region] [nvarchar](15) NULL,
	[Country] [nvarchar](15) NULL
)


select * from north.STG_Employees
select * from north_factsdim.Employees_Dim

--using SCD -1 for populating the data 
merge into north_factsdim.employees_dim t
using north.STG_employees s
on t.employeeID = s.employeeID
when matched and(s.lastname <> t.lastname or s.firstname <> t.firstname or s.birthdate<>t.birthdate or s.hiredate<>t.hiredate or s.region<>t.region or s.country<>t.country)
then update
set
t.employeekey = Hashbytes('MD5',concat(s.employeeID, s.lastname, s.firstname, s.birthdate, s.hiredate, s.region, s.country)),
t.lastname = s.lastname,
t.firstname = s.firstname,
t.birthdate = s.birthdate,
t.hiredate = s.hiredate,
t.region = s.region,
t.country = s.country
when not matched
then insert(employeekey,employeeID, lastname, firstname, birthdate, hiredate, region, country) values(Hashbytes('MD5',concat(s.employeeID, s.lastname, s.firstname, s.birthdate, s.hiredate, s.region, s.country)), s.employeeID, s.lastname, s.firstname, s.birthdate, s.hiredate, s.region, s.country)
when not matched by source
then delete;


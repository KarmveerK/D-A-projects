--creating a landing table for customers
CREATE TABLE [north].[Customers](
	[CustomerID] [nchar](5) NOT NULL,
	[CompanyName] [nvarchar](40) NOT NULL,
	[ContactName] [nvarchar](30) NULL,
	[ContactTitle] [nvarchar](30) NULL,
	[Address] [nvarchar](60) NULL,
	[City] [nvarchar](15) NULL,
	[Region] [nvarchar](15) NULL,
	[PostalCode] [nvarchar](10) NULL,
	[Country] [nvarchar](15) NULL,
	[Phone] [nvarchar](24) NULL,
	[Fax] [nvarchar](24) NULL,
 )
 --customers staging table creation
CREATE TABLE [north].[STG_Customers](
	[CustomerID] [nchar](5) NOT NULL,
	[CompanyName] [nvarchar](40) NOT NULL,
	[ContactName] [nvarchar](30) NULL,
	[ContactTitle] [nvarchar](30) NULL,
	[Address] [nvarchar](60) NULL,
	[City] [nvarchar](15) NULL,
	[Region] [nvarchar](15) NULL,
	[PostalCode] [nvarchar](10) NULL,
	[Country] [nvarchar](15) NULL,
	[Phone] [nvarchar](24) NULL,
	[Fax] [nvarchar](24) NULL
)
--populating the customers staging table using SCD type 1
merge into north.STG_Customers sc
using north.Customers lc
on sc.CustomerID = lc.CustomerID
when matched and (sc.CompanyName <> lc.CompanyName or sc.ContactName <> lc.ContactName or sc.ContactTitle <> lc.ContactTitle or sc.Address<>lc.Address or sc.City<>lc.City or sc.Region<>lc.Region or sc.PostalCode<>lc.PostalCode or sc.Country<>lc.Country or sc.Phone<>lc.Phone or sc.Fax<>lc.Fax)
then update
set
sc.CompanyName = lc.CompanyName,
sc.ContactName = lc.ContactName,
sc.ContactTitle = lc.ContactTitle,
sc.Address = lc.Address,
sc.City = lc.City,
sc.Region = lc.Region,
sc.PostalCode = lc.PostalCode,
sc.Country = lc.Country,
sc.Phone = lc.Phone,
sc.Fax = lc.Fax
when not matched
then insert values(lc.CustomerID, lc.CompanyName, lc.ContactName, lc.ContactTitle, lc.Address, lc.City, lc.Region, lc.PostalCode, lc.Country, lc.Phone, lc.Fax)
when not matched by source
then delete;



-- customers dimension creation

CREATE TABLE [north_factsdim].[Customers_Dim](
    [CustomerKey][integer] primary key,
	[CustomerID] [nchar](5) NOT NULL,
	[CompanyName] [nvarchar](40) NOT NULL,
	[ContactName] [nvarchar](30) NULL,
	[ContactTitle] [nvarchar](30) NULL,
	[Address] [nvarchar](60) NULL,
	[City] [nvarchar](15) NULL,
	[Region] [nvarchar](15) NULL,
	[PostalCode] [nvarchar](10) NULL,
	[Country] [nvarchar](15) NULL,
	[Phone] [nvarchar](24) NULL,
	[Fax] [nvarchar](24) NULL,
	VersionNumber integer NOT NULL DEFAULT 0
)

--populating the customers dimension table using SCD type 2

--merge statement for scd type 2
merge into [north_factsdim].[Customers_Dim] lc
using [north].[STG_Customers] sc
on lc.CustomerID = sc.CustomerID
when matched AND (lc.CustomerKey <> Hashbytes('MD5',concat(sc.CustomerID, sc.CompanyName, sc.ContactName, sc.ContactTitle, sc.Address, sc.City, sc.Region, sc.PostalCode, sc.Country, sc.Phone, sc.Fax, 0)))
then update 
set
lc.versionNumber = lc.versionNumber-1 
when not matched 
then insert values(Hashbytes('MD5',concat(sc.CustomerID, sc.CompanyName, sc.ContactName, sc.ContactTitle, sc.Address, sc.City, sc.Region, sc.PostalCode, sc.Country, sc.Phone, sc.Fax, 0)), sc.CustomerID, sc.CompanyName, sc.ContactName, sc.ContactTitle, sc.Address, sc.City, sc.Region, sc.PostalCode, sc.Country, sc.Phone, sc.Fax, 0)
when not matched by source
then delete;
insert into [north_factsdim].[Customers_Dim](CustomerKey,CustomerID, CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,VersionNumber)
select Hashbytes('MD5',concat(CustomerID, CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax, 0)) as skey,*,0 from north.STG_Customers 
where Hashbytes('MD5',concat(CustomerID, CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax, 0)) not in (Select CustomerKey from  [north_factsdim].[Customers_Dim] );
 




 select * from north.STG_Customers
 select * from north_factsdim.Customers_Dim

 update north.STG_Customers
 set CompanyName = 'EY' where CustomerID = 'WOLZA'

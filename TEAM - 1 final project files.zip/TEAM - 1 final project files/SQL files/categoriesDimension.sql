
--categories landing table creation
CREATE TABLE [north].[Categories](
	[CategoryID] [int] NOT NULL,
	[CategoryName] [nvarchar](15) NOT NULL,
	[Description] [ntext] NULL
)
--populating the landing table done using python

--categories staging table creation
CREATE TABLE [north].[STG_Categories](
	[CategoryID] [int] NOT NULL,
	[CategoryName] varchar(max) NOT NULL,
	[Description] varchar(max) NULL
)

--populating the staging table
merge into north.STG_Categories sc
using north.Categories lc
on sc.CategoryID = lc.CategoryID
when matched and (sc.categoryName <> lc.categoryName or sc.description <> lc.description) -- when both id is same
then update
set
sc.CategoryID = lc.CategoryID,
sc.CategoryName = lc.CategoryName,
sc.Description = lc.Description
when not matched
then insert values(lc.categoryID, lc.CategoryName, lc.Description)
when not matched by source
then delete;

truncate table north_factsdim.categories_dim


--categories dimension
CREATE TABLE [north_factsdim].[Categories_Dim](
    [CategoriesKey][integer] primary key,
	[CategoryID] [int] NOT NULL,
	[CategoryName] [nvarchar](max) NOT NULL,
	[Description] [nvarchar](max) NULL
)

--populating the data in categories dimension
select * from north.STG_Categories
select * from north_factsdim.Categories_Dim


merge into [north_factsdim].[Categories_Dim] c
using north.STG_Categories s
on c.CategoryID = s.CategoryID
when matched and(s.CategoryName <> c.CategoryName or s.Description <> c.Description)
then update
set
c.CategoriesKey = Hashbytes('MD5',concat(s.CategoryID, s.CategoryName, s.Description)),
c.CategoryName = s.CategoryName,
c.Description = s.Description
when not matched
then insert(CategoriesKey,CategoryID, CategoryName, Description) values(Hashbytes('MD5',concat(s.CategoryID, s.CategoryName, s.Description)), s.CategoryID, s.CategoryName, s.Description)
when not matched by source
then delete;
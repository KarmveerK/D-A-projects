--creating the suppliers data landing table
CREATE TABLE [north].[Suppliers](
	[SupplierID] [int] NOT NULL,
	[CompanyName] [nvarchar](40) NOT NULL,
	[ContactName] [nvarchar](30) NULL,
	[ContactTitle] [nvarchar](30) NULL,
	[Address] [nvarchar](60) NULL,
	[City] [nvarchar](15) NULL,
	[Region] [nvarchar](15) NULL,
	[PostalCode] [nvarchar](10) NULL,
	[Country] [nvarchar](15) NULL,
	[Phone] [nvarchar](24) NULL,
	[Fax] [nvarchar](24) NULL,
	[HomePage] [ntext] NULL)

--creating the suppliers staging table 
CREATE TABLE north.STG_Suppliers(
	[SupplierID] [int]  NOT NULL,
	[CompanyName] [nvarchar](40) NOT NULL,
	[ContactName] [nvarchar](30) NULL,
	[ContactTitle] [nvarchar](30) NULL,
	[Address] [nvarchar](60) NULL,
	[City] [nvarchar](15) NULL,
	[Region] [nvarchar](15) NULL,
	[PostalCode] [nvarchar](10) NULL,
	[Country] [nvarchar](15) NULL,
	[Phone] [nvarchar](24) NULL,
	[Fax] [nvarchar](24) NULL,
	[HomePage] [varchar](max) NULL)
 
 --populating the suppliers staging table using SCD - 1
merge into north.STG_Suppliers sc
using north.Suppliers lc
on sc.SupplierID= lc.SupplierID
when matched and (sc.CompanyName <> lc.CompanyName or sc.ContactName <> lc.ContactName or sc.ContactTitle <> lc.ContactTitle or sc.Address <> lc.Address or sc.City <> lc.City or sc.Region <> lc.Region or sc.PostalCode <> lc.PostalCode or sc.Country <> lc.Country or sc.Phone <> lc.Phone or sc.Fax <> lc.Fax or sc.HomePage <> lc.HomePage)
then update 
set
sc.SupplierID=lc.SupplierID,
sc.CompanyName=lc.CompanyName,
sc.ContactName=lc.ContactName,
sc.ContactTitle=lc.ContactTitle,
sc.Address=lc.Address,
sc.City=lc.City,
sc.Region=lc.Region,
sc.PostalCode=lc.PostalCode,
sc.Country=lc.Country,
sc.Phone=lc.Phone,
sc.Fax=lc.Fax,
sc.HomePage=lc.HomePage
when not matched 
then insert values (lc.SupplierID,lc.CompanyName,lc.ContactName,lc.ContactTitle,lc.Address,lc.City,lc.Region,lc.PostalCode,lc.Country,lc.Phone,lc.Fax,lc.HomePage)
when not matched by source
then delete;




--suppliers dimension creation
CREATE TABLE [north_factsdim].[Suppliers_Dim](
    [SupplierKey][integer]primary key,
	[SupplierID] [int] not null,
	[CompanyName] [nvarchar](40) NOT NULL,
	[ContactName] [nvarchar](30) NULL,
	[ContactTitle] [nvarchar](30) NULL,
	[Address] [nvarchar](60) NULL,
	[City] [nvarchar](15) NULL,
	[Region] [nvarchar](15) NULL,
	[PostalCode] [nvarchar](10) NULL,
	[Country] [nvarchar](15) NULL,
	[Phone] [nvarchar](24) NULL,
	[Fax] [nvarchar](24) NULL,
	[HomePage] varchar(max) NULL
)

--populating the data in suppliers dimension using SCD - 1
merge into north_factsdim.suppliers_dim t
using north.STG_suppliers s
on t.supplierID = s.supplierID
when matched and(s.companyName <> t.companyName or s.contactName <> t.contactName or s.contactTitle<>t.contactTitle or s.Address<>t.address or s.city<>t.city or s.region<>t.region or s.postalCode<>t.postalCode or s.country<>t.country or s.phone<>t.phone)
then update
set
t.supplierKey = Hashbytes('MD5',concat(s.supplierID, s.companyName, s.contactName, s.ContactTitle, s.Address, s.city, s.region, s.postalCode, s.country, s.phone)),
t.companyName = s.companyName,
t.contactName = s.contactName,
t.ContactTitle = s.ContactTitle,
t.Address = s.Address,
t.city = s.city,
t.region = s.region,
t.postalCode = s.postalCode,
t.country = s.country,
t.phone = s.phone

when not matched
then insert(SupplierKey,supplierID, companyName, contactName, ContactTitle, Address, city, region, postalCode, country, phone) values(Hashbytes('MD5',concat(s.supplierID, s.companyName, s.contactName, s.ContactTitle, s.Address, s.city, s.region, s.postalCode, s.country, s.phone)), s.supplierID, s.companyName, s.contactName, s.ContactTitle, s.Address, s.city, s.region, s.postalCode, s.country, s.phone)
when not matched by source
then delete;


select * from north_factsdim.suppliers_dim
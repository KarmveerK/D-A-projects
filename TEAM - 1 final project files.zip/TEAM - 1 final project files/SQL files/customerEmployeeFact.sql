--customerEmployeeFact

create table [north_factsdim].[CustomerEmployee_Fact](
[CustomerKey][integer]FOREIGN KEY REFERENCES north_factsdim.Customers_Dim(CustomerKey),
[EmployeeKey][integer]FOREIGN KEY REFERENCES north_factsdim.Employees_Dim(EmployeeKey),
[CalendarKey][integer]FOREIGN KEY REFERENCES north_factsdim.Calendar_Dim(CalendarKey),
[OrderId] varchar(max) not null,
[Sales][integer]not null
);

-- Insert data into the SalesFact table
/*
INSERT INTO north_factsdim.CustomerEmployee_Fact(CustomerKey, EmployeeKey, CalendarKey, OrderID, Sales)
SELECT
    c.CustomerKey,
    e.EmployeeKey,
    cal.CalendarKey,
    o.OrderID,
    sales = (select sum(UnitPrice*Quantity) from north.OrderDetails where OrderID = o.OrderID)
FROM
    north.STG_Orders o
    JOIN north_factsdim.Calendar_Dim cal ON o.OrderDate = cal.FullDate
    JOIN north_factsdim.Employees_Dim e ON o.EmployeeID = e.EmployeeID
    JOIN north_factsdim.Customers_Dim c ON o.CustomerID = c.CustomerID
*/


WITH LatestCustomers AS (
  select * from north_factsdim.Customers_Dim where VersionNumber = 0
)
INSERT INTO north_factsdim.CustomerEmployee_Fact(CustomerKey, EmployeeKey, CalendarKey, OrderID, Sales)
SELECT
    lc.CustomerKey,
    e.EmployeeKey,
    cal.CalendarKey,
    o.OrderID,
    sales = (SELECT SUM(UnitPrice * Quantity) FROM north.OrderDetails WHERE OrderID = o.OrderID)
FROM
    north.STG_Orders o
    JOIN north_factsdim.Calendar_Dim cal ON o.OrderDate = cal.FullDate
    JOIN north_factsdim.Employees_Dim e ON o.EmployeeID = e.EmployeeID
    JOIN LatestCustomers lc ON o.CustomerID = lc.CustomerID;



select * from north_factsdim.CustomerEmployee_Fact


















--testing
select * from  north_factsdim.Customers_Dim where customerID = 'WOLZA';
select distinct count(CustomerKey) from north_factsdim.CustomerEmployee_Fact ;
--1021411082
--1753469333




--ROUGH
select * from north_factsdim.CustomerEmployee_Fact
--select * from north.STG_Orders

select * from north.OrderDetails where OrderID = 10248